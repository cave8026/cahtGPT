package common;

import java.sql.*;
import javax.naming.*;
import javax.sql.DataSource;

/**
 * DB 연결을 관리하는 공통 클래스입니다. (톰캣의 DBCP 사용)
 */
public class DBConnPool {
    // 하위 DAO에서 바로 사용할 수 있도록 protected로 선언
    protected Connection con;
    protected PreparedStatement psmt;
    protected ResultSet rs;

    public DBConnPool() {
        // 우선 JNDI로 DataSource를 찾아 시도합니다.
        try {
            System.out.println("[DBConnPool] Attempting JNDI DataSource lookup: java:/comp/env/jdbc/urdb");
            Context initContext = new InitialContext();
            Context envContext = (Context)initContext.lookup("java:/comp/env");
            DataSource ds = (DataSource)envContext.lookup("jdbc/urdb");
            con = ds.getConnection();
            System.out.println("[DBConnPool] Got connection from DataSource (JNDI).");
            return;
        } catch (Exception e) {
            System.err.println("[DBConnPool] JNDI lookup or getting Connection failed: " + e.getMessage());
            // 남긴 스택트레이스는 개발 시 확인을 돕습니다.
            e.printStackTrace();
        }

        // 개발 환경에서 JNDI가 동작하지 않거나 서버 레벨 리소스/드라이버 문제가 있을 경우
        // 로컬에서 직접 DriverManager로 연결하는 대체 경로를 시도합니다.
        try {
            System.out.println("[DBConnPool] Attempting fallback using DriverManager (development mode).");
            // 드라이버 클래스 로드 (ojdbc가 WEB-INF/lib에 있으면 webapp 클래스패스에서 로드됨)
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:xe";
            String user = "petcare";
            String password = "1234";
            con = DriverManager.getConnection(url, user, password);
            System.out.println("[DBConnPool] Got connection from DriverManager fallback.");
            return;
        } catch (ClassNotFoundException cnfe) {
            System.err.println("[DBConnPool] Oracle JDBC Driver class not found (ojdbc jar missing). Place ojdbc jar into Tomcat/lib or WEB-INF/lib.");
            cnfe.printStackTrace();
        } catch (Exception e) {
            System.err.println("[DBConnPool] DriverManager fallback failed: " + e.getMessage());
            e.printStackTrace();
        }

        // 여기에 오면 모든 시도가 실패한 상태입니다. 하위 DAO에서 con==null을 체크합니다.
        System.err.println("[DBConnPool] All attempts to obtain DB connection failed. con is null.");
    }

    public void close() {
        try { if(rs != null) rs.close(); } catch(Exception e) {}
        try { if(psmt != null) psmt.close(); } catch(Exception e) {}
        try { if(con != null) con.close(); } catch(Exception e) {}
    }
}